SELECT ROW_NUMBER() OVER (PARTITION BY SUBSTRING(LastName,1,1) 
       ORDER BY LastName) AS RowNum, 
       CONCAT(FirstName,' ',LastName) AS CustomerName, 
	   UnclearedBalance
  FROM CustomerDetails.Customers
 WHERE UnclearedBalance is not null
 ORDER BY LastName DESC