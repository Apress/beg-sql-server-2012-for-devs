ALTER SEQUENCE CustomerDetails.SeqFinancialProducts
CYCLE
RESTART WITH 1