SELECT ProductId,ProductName
FROM CustomerDetails.FinancialProducts
ORDER BY ProductId