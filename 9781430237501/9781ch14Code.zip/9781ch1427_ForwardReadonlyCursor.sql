DECLARE @FirstName varchar(50), @LastName varchar(50),
        @ProductName nvarchar(50), @Amount money,
        @LastCollect datetime

DECLARE @TotalCollected money = 0

DECLARE FinProductsColl CURSOR 
     FOR SELECT c.FirstName, c.LastName, f.ProductName, 
                cp.AmountToCollect, cp.LastCollected
           FROM CustomerDetails.Customers c 
           JOIN CustomerDetails.CustomerProducts cp 
                 ON cp.CustomerId = c.CustomerId
           JOIN CustomerDetails.FinancialProducts f 
                 ON f.ProductId = cp.FinancialProductId
          WHERE cp.Frequency = 2
            AND cp.LastCollected BETWEEN '1 Mar 2012' AND '31 Mar 2012'

OPEN FinProductsColl

FETCH NEXT FROM FinProductsColl 
INTO @FirstName, @LastName, @ProductName, @Amount, @LastCollect

WHILE @@FETCH_STATUS = 0
BEGIN

    SELECT @TotalCollected = @TotalCollected + @Amount

    SELECT @FirstName, @LastName, @ProductName, @Amount,
       'Running total is ' + CONVERT(varchar(20),@TotalCollected)

FETCH NEXT FROM FinProductsColl 
INTO @FirstName, @LastName, @ProductName, @Amount, @LastCollect

END

SELECT 'Total collected is ' + CONVERT(varchar(20),@TotalCollected)

CLOSE FinProductsColl

DEALLOCATE FinProductsColl

