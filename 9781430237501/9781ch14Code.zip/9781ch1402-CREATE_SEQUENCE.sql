CREATE SEQUENCE CustomerDetails.SeqFinancialProducts
AS int
START WITH 42
MAXVALUE 44
NO CACHE

