SELECT MAX(ProductId) + 1
  FROM CustomerDetails.FinancialProducts