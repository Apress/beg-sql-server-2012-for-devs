USE [master]
GO
CREATE LOGIN [FAT-BELLY-SONY\Apress_Product_Controllers] FROM WINDOWS 
WITH DEFAULT_DATABASE=[master]
GO
USE [ApressFinancial]
GO
CREATE USER [FAT-BELLY-SONY\Apress_Product_Controllers] 
FOR LOGIN [FAT-BELLY-SONY\Apress_Product_Controllers]
GO
CREATE LOGIN [FAT-BELLY-SONY\Apress_Client_Information]
FROM WINDOWS
WITH DEFAULT_DATABASE=[ApressFinancial],
DEFAULT_LANGUAGE=[us_english]
GO
ALTER LOGIN [FAT-BELLY-SONY\Apress_Product_Controllers]
WITH DEFAULT_DATABASE=ApressFinancial
GO
CREATE USER [FAT-BELLY-SONY\Apress_Client_Information]
FOR LOGIN [FAT-BELLY-SONY\Apress_Client_Information]
GO
USE ApressFinancial
GO
CREATE SCHEMA TransactionDetails AUTHORIZATION dbo
GO
CREATE SCHEMA ShareDetails AUTHORIZATION dbo
GO
CREATE SCHEMA CustomerDetails AUTHORIZATION dbo
GO
