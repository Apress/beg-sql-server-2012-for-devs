/*BEGIN TRAN
   SELECT COUNT(*) FROM TransactionDetails.Transactions
   DELETE ShareDetails.SharePrices

   --- ON FIRST PASS DO NOT RUN ANY CODE PAST THIS POINT
   --- ON FIRST PASS DO NOT RUN ANY CODE PAST THIS POINT
   --- ON FIRST PASS DO NOT RUN ANY CODE PAST THIS POINT
   --- ON FIRST PASS DO NOT RUN ANY CODE PAST THIS POINT
   --- ON FIRST PASS DO NOT RUN ANY CODE PAST THIS POINT

   DELETE TransactionDetails.Transactions
   SELECT COUNT(*) FROM TransactionDetails.Transactions
*/
rollback tran
