Late in Chapter 9 you will need to insert a bulk amount of data. The following file has that information.

The file is 9781ch0912-BulkDataInsertion.sql

It is also available as a separate file on www.fat-belly.com

Open this file and Execute when asked to do so.

Thanks

Robin Dewson