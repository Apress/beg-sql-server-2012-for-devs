INSERT INTO CustomerDetails.Customers
(Title,LastName,FirstName,
OtherInitials,AddressLine1,TownOrCity,USState,
AccountType,ClearedBalance,UnclearedBalance)
VALUES (3,'Lomas','Aubrey',NULL,'11c Clerkenwell',2654,0,2,437.97,-10.56)
