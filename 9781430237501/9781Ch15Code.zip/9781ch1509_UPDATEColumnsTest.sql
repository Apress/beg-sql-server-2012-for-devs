--begin tran
SELECT *
  FROM TransactionDetails.Transactions
 WHERE CustomerId = 2
SELECT ClearedBalance
  FROM CustomerDetails.Customers
 WHERE CustomerId = 2
UPDATE TransactionDetails.Transactions
   SET Amount = 100
 WHERE TransactionId = 1004
SELECT *
  FROM TransactionDetails.Transactions
 WHERE CustomerId = 2
SELECT ClearedBalance
  FROM CustomerDetails.Customers
 WHERE CustomerId = 2
--rollback tran