--BEGIN TRAN
SELECT ClearedBalance
  FROM CustomerDetails.Customers
 WHERE customerId=2

INSERT INTO TransactionDetails.Transactions (CustomerId,TransactionType,
Amount,RelatedProductId, DateEntered)
VALUES (2,1,200,1,GETDATE())

SELECT ClearedBalance
  FROM CustomerDetails.Customers
 WHERE customerId=2
--ROLLBACK TRAN   
