UPDATE CustomerDetails.Customers
SET ClearedBalance = 0
WHERE ClearedBalance IS NULL
GO
ALTER TABLE CustomerDetails.Customers
ALTER COLUMN ClearedBalance money NOT NULL
GO
