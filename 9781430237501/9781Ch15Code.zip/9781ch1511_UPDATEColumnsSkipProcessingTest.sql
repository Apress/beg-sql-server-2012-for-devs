--begin tran
SELECT *
  FROM TransactionDetails.Transactions
 WHERE TransactionId=1004
SELECT ClearedBalance
  FROM CustomerDetails.Customers
 WHERE CustomerId = 2
UPDATE TransactionDetails.Transactions
   SET DateEntered = DATEADD(dd,-1,DateEntered)
 WHERE TransactionId = 1004
SELECT *
  FROM TransactionDetails.Transactions
 WHERE TransactionId=1004
SELECT ClearedBalance
  FROM CustomerDetails.Customers
 WHERE CustomerId = 2
 --rollback tran