SELECT FirstName As 'First Name',LastName AS 'Surname',
ClearedBalance Balance
FROM CustomerDetails.Customers

