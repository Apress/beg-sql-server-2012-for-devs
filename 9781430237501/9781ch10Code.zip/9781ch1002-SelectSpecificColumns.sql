SELECT firstname,lastname,clearedbalance
FROM CustomerDetails.Customers
