SET QUOTED_IDENTIFIER OFF
SELECT Description,CurrentPrice 
  FROM ShareDetails.Shares
 WHERE Description <> "Lomas Ambulances"

SELECT Description,CurrentPrice 
  FROM ShareDetails.Shares
 WHERE NOT Description = "Lomas Ambulances "
