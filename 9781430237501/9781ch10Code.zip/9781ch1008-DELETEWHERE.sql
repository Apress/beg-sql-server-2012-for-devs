DELETE
FROM ShareDetails.SharePrices
WHERE PriceDate BETWEEN '1 Jan 2012' and '3 Jan 2012'
AND Price > 23