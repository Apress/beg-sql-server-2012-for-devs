SELECT FirstName + ' ' + LastName
FROM CustomerDetails.Customers
WHERE LastName LIKE '%-Smith'
