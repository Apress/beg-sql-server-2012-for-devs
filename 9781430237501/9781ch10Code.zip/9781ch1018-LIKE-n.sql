SELECT FirstName + ' ' + LastName
FROM CustomerDetails.Customers
WHERE FirstName + LastName LIKE '%Q%'
