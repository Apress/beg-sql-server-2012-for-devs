SELECT FirstName, LastName, ClearedBalance FROM CustomerDetails.Customers 

