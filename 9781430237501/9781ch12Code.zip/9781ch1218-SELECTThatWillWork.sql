SELECT FirstName, LastName FROM CustomerDetails.Customers 
