
INSERT INTO TransactionDetails.Transactions
(CustomerId,TransactionType,DateEntered,Amount,RelatedProductId)
VALUES (1,1,'1 Aug 2011',100.00,1),
 (1,1,'3 Aug 2011',75.67,1),
 (1,2,'5 Aug 2011',35.20,1),
 (1,2,'6 Aug 2011',20.00,1)



