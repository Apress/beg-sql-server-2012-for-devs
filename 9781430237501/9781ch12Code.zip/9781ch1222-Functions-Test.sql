
SELECT TransactionDetails.fn_IntCalc(DEFAULT,2000,'Mar 1 2012','Mar 10 2012')