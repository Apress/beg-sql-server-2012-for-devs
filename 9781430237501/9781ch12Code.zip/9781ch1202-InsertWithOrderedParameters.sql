CustomerDetails.apf_InsertCustomer 1,'Steve',NULL,'Nicklin','645 Hyde Park',NULL,NULL,7545,'W1A 1AA',0,1
  /*  @CustTitle int,
    @FirstName varchar(50) ,
    @CustInitials nvarchar(10),
    @LastName varchar(50),
    @AddressLine1 varchar(50),
    @AddressLine2 varchar(50),
    @AddressLine3 varchar(50),
    @TownOrCity int,
    @ZipCode varchar(20),
    @USState tinyint,
    @AccountTypeId int */