GRANT EXECUTE ON CustomerDetails.apf_CustBalances TO [FAT-BELLY-SONY\Apress_Product_Controllers]

