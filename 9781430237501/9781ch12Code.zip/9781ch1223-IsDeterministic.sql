SELECT OBJECTPROPERTY(OBJECT_ID('TransactionDetails.fn_IntCalc'), 'IsDeterministic')
GO
