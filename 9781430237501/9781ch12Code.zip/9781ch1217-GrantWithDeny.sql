GRANT SELECT ON CustomerDetails.Customers (CustomerId,
Title, FirstName, OtherInitials, LastName,AddressLine1,
AddressLine2,AddressLine3,TownOrCity,ZipCode,USState,
AccountType, UnclearedBalance, DateOpened,DateClosed) 
TO [FAT-BELLY-SONY\Apress_Product_Controllers]
