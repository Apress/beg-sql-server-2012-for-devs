EXEC  CustomerDetails.apf_CustMovement 1,'1 Aug 2011','31 Aug 2011'
