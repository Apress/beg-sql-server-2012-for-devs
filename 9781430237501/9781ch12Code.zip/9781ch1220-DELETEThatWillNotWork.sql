DELETE FROM CustomerDetails.Customers WHERE CustomerId = 2
