-- =============================================
-- Create index basic template
-- =============================================
USE ApressFinancial
GO

CREATE INDEX IX_CustomerProducts_CustId
ON CustomerDetails.CustomerProducts 
(
	CustomerId
)
GO
