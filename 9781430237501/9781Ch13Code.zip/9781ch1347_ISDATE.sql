DECLARE @IsDate char(15)
SET @IsDate = '31 Sep 2011'
SELECT ISDATE(@IsDate)
