DECLARE @OldTime datetime
SET @OldTime = '24 March 2012 3:00 PM'
SELECT DATEADD(hh,4,@OldTime)

