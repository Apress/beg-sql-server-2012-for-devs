DECLARE @MyDate DATETIME 
SELECT @MyDate = 'Jun 1 2011'
SELECT FORMAT(@MyDate, 'dd MMM yyyy', 'en-GB' ) AS UKDate

