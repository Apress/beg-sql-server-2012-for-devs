DECLARE @StringTest char(10)
SET @StringTest = 'Robin     '
SELECT LEFT(@StringTest,3)
