DECLARE @StringTest char(10)
SET @StringTest = 'Robin     '
SELECT UPPER(@StringTest)
