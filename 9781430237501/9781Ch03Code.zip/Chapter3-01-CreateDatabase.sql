CREATE DATABASE ApressFinancial 
CONTAINMENT = NONE
ON  PRIMARY 
( NAME = N'ApressFinancial', 
FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.APRESS_DEV1\MSSQL\DATA\ApressFinancial.mdf' , SIZE = 4096KB , 
MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'ApressFinancial_log', 
FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.APRESS_DEV1\MSSQL\DATA\ApressFinancial_log.ldf' , 
SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
 COLLATE SQL_Latin1_General_CP1_CI_AS
GO
