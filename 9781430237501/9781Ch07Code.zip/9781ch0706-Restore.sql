USE [master]
GO
RESTORE DATABASE [ApressFinancial] FROM  DISK = N'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak' WITH  FILE = 2,  NORECOVERY,  NOUNLOAD,  REPLACE,  STATS = 5
RESTORE DATABASE [ApressFinancial] FROM  DISK = N'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak' WITH  FILE = 3,  NORECOVERY,  NOUNLOAD,  STATS = 5
RESTORE LOG [ApressFinancial] FROM  DISK = N'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak' WITH  FILE = 4,  NOUNLOAD,  STATS = 5

GO


