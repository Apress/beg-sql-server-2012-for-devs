USE [master]
BACKUP LOG [ApressFinancial] TO  DISK = 
N'C:\Program Files\Microsoft SQL Server\MSSQL11.APRESS_DEV1\MSSQL\Backup\ApressFinancial_LogBackup_2011-12-30_10-36.bak' 
WITH NOFORMAT, NOINIT,  NAME = 
N'ApressFinancial_LogBackup_2011-12-30_10-36-00', 
NOSKIP, NOREWIND, NOUNLOAD, NORECOVERY,  STATS = 5
RESTORE DATABASE [ApressFinancial] FROM  DISK = 
N'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak' 
WITH  FILE = 2,  NORECOVERY,  NOUNLOAD,  STATS = 5
RESTORE DATABASE [ApressFinancial] FROM  DISK = 
N'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak' 
WITH  FILE = 3,  NORECOVERY,  NOUNLOAD,  STATS = 5
RESTORE LOG [ApressFinancial] FROM  DISK = 
N'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak' 
WITH  FILE = 4,  NORECOVERY,  NOUNLOAD,  STATS = 5
RESTORE LOG [ApressFinancial] FROM  DISK = 
N'C:\Program Files\Microsoft SQL Server\MSSQL11.APRESS_DEV1\MSSQL\Backup\ApressFinancial_LogBackup_2011-12-30_10-36.bak' 
WITH  FILE = 2,  NOUNLOAD,  STATS = 5,  STOPAT = N'2011-12-30T13:08:00'
GO

