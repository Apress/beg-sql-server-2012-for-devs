BACKUP DATABASE ApressFinancial
TO DISK = 'C:\SQLServerBackups\ApressFinancial\ApressFinancialFirstFullBackup.bak'
WITH NAME = 'ApressFinancial-Full Database Backup',
SKIP,
NOUNLOAD,
STATS = 10
