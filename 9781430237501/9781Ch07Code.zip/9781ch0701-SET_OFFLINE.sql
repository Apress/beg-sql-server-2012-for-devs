USE master
GO
ALTER DATABASE ApressFinancial
SET OFFLINE
