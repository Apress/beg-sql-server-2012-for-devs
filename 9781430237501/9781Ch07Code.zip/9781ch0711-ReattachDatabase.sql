CREATE DATABASE ApressFinancial
ON (FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL11.APRESS_DEV1\MSSQL\DATA\ApressFinancial.MDF')
FOR ATTACH
