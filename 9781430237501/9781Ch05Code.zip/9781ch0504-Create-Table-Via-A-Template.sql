-- =========================================
-- Create table template with IDENTITY
-- =========================================
USE ApressFinancial
GO

IF OBJECT_ID('ShareDetails.Shares', 'U') IS NOT NULL
  DROP TABLE ShareDetails.Shares
GO

CREATE TABLE ShareDetails.Shares
(
	ShareId int IDENTITY (1,1) NOT NULL, 
	Description varchar(50) NOT NULL, 
	StockExchangeTicker varchar(50) NULL, 
	CurrentPrice numeric(18,5) NOT NULL
)
GO
