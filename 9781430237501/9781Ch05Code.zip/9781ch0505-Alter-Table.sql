ALTER TABLE TransactionDetails.TransactionTypes
ADD AffectCashBalance bit NULL
GO
