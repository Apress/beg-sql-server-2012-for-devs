BEGIN TRAN
UPDATE CustomerDetails.vw_CustTrans
   SET DateEntered = '1 Feb 2012'

ROLLBACK TRAN
