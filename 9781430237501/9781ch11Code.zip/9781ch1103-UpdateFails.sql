BEGIN TRAN
UPDATE CustomerDetails.vw_CustTrans
   SET DateEntered = '1 Dec 2011'

ROLLBACK TRAN
