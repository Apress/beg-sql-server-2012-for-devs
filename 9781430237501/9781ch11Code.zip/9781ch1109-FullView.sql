USE [ApressFinancial]
GO
DROP VIEW [CustomerDetails].[vw_CustFinProducts]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [CustomerDetails].[vw_CustFinProducts] 
    WITH SCHEMABINDING
AS
SELECT c.FirstName + ' ' + c.LastName AS CustomerName,
c.CustomerId, fp.ProductName, cp.AmountToCollect, cp.Frequency,
cp.LastCollected
FROM CustomerDetails.Customers c
JOIN CustomerDetails.CustomerProducts cp ON 
  cp.CustomerId = c.CustomerId
JOIN CustomerDetails.FinancialProducts fp ON
  fp.ProductId = cp.FinancialProductId
GO


