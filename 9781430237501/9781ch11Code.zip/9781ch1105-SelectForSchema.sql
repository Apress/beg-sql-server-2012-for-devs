SELECT c.FirstName + ' ' + c.LastName AS CustomerName,
c.CustomerId, fp.ProductName, cp.AmountToCollect, cp.Frequency,
cp.LastCollected
FROM CustomerDetails.Customers c
JOIN CustomerDetails.CustomerProducts cp ON cp.CustomerId = c.CustomerId
JOIN CustomerDetails.FinancialProducts fp ON
  fp.ProductId = cp.FinancialProductId
